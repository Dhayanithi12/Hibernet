package com.pizza.online.model.stocks;

public enum Menu {
	SUPREME, SIGNATURE, FAVOURITE, CLASSIC, OVERLOADED;
}
