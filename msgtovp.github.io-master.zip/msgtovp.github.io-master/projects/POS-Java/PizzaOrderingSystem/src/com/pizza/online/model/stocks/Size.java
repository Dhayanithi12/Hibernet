package com.pizza.online.model.stocks;

public enum Size {
	SMALL, MEDIUM, LARGE;
}
